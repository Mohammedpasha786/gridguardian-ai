"""
GridGuardian AI — Gradio Web Demo
Deploys to Hugging Face Spaces with zero config changes.

Tab 1: Climate Risk Assessment
Tab 2: Demand Forecast
Tab 3: Grid Telemetry
Tab 4: Dispatch Optimizer
Tab 5: Full Pipeline Briefing (requires GOOGLE_API_KEY secret in HF Space settings)
"""

from __future__ import annotations

import asyncio
import json
import os
import sys

import gradio as gr

# Allow running from repo root without installing the package
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from gridguardian.tools.grid_tools import (
    get_climate_risk_assessment,
    get_demand_forecast,
    get_dispatch_plan,
    get_grid_telemetry,
    get_weather_forecast,
)

# ──────────────────────────────────────────────────────────────────────────────
# Helper
# ──────────────────────────────────────────────────────────────────────────────

def _pretty(d: dict) -> str:
    return json.dumps(d, indent=2)


PRESETS = {
    "Chennai, India (coastal)": (13.08, 80.27),
    "Mumbai, India (high flood risk)": (19.07, 72.87),
    "London, UK (temperate)": (51.50, -0.12),
    "New Orleans, USA (storm surge)": (29.95, -90.07),
    "Nairobi, Kenya (equatorial solar)": (-1.29, 36.82),
    "Jakarta, Indonesia (subsidence risk)": (-6.21, 106.84),
}

# ──────────────────────────────────────────────────────────────────────────────
# Tab 1 — Climate Risk
# ──────────────────────────────────────────────────────────────────────────────

def run_climate_risk(region: str, lat: float, lon: float) -> tuple[str, str]:
    try:
        result = get_climate_risk_assessment(region, lat, lon)
        risk_reserve = round(
            0.4 * max(result["flood_risk_index"], result["storm_surge_risk_index"], result["heatwave_probability"]),
            3,
        )
        summary = (
            f"**Recommended battery reserve: {risk_reserve*100:.1f}%**\n\n"
            f"- Heatwave probability: **{result['heatwave_probability']:.1%}**\n"
            f"- Flood risk index: **{result['flood_risk_index']:.3f}**\n"
            f"- Storm surge risk: **{result['storm_surge_risk_index']:.3f}**\n"
            f"- Sea-level rise: **{result['sea_level_rise_mm_per_yr']} mm/yr**\n"
            f"- Extreme event trend: **+{result['extreme_event_trend_pct']}%**\n\n"
            f"*Source: {result['source']}*"
        )
        return summary, _pretty(result)
    except Exception as e:
        return f"❌ Error: {e}", ""


# ──────────────────────────────────────────────────────────────────────────────
# Tab 2 — Demand Forecast
# ──────────────────────────────────────────────────────────────────────────────

def run_demand_forecast(lat: float, lon: float, hours: int) -> tuple[str, str, object]:
    try:
        result = get_demand_forecast(lat, lon, hours)
        points = result["forecast"]
        peak = max(points, key=lambda p: p["predicted_load_kw"])
        avg = round(sum(p["predicted_load_kw"] for p in points) / len(points), 1)

        summary = (
            f"**{len(points)}-hour demand forecast**\n\n"
            f"- Peak load: **{peak['predicted_load_kw']} kW** at `{peak['timestamp']}`\n"
            f"- Average load: **{avg} kW**\n"
            f"- Uncertainty range: "
            f"{round(min(p['lower_bound_kw'] for p in points),1)} – "
            f"{round(max(p['upper_bound_kw'] for p in points),1)} kW"
        )

        # Build plot data
        import gradio as gr
        timestamps = [p["timestamp"][-8:-3] for p in points]   # HH:MM
        loads = [p["predicted_load_kw"] for p in points]
        lowers = [p["lower_bound_kw"] for p in points]
        uppers = [p["upper_bound_kw"] for p in points]

        plot_data = {
            "data": [
                {"x": timestamps, "y": loads, "type": "scatter", "name": "Forecast", "line": {"color": "#56c2e8"}},
                {"x": timestamps, "y": uppers, "type": "scatter", "name": "Upper bound",
                 "line": {"dash": "dot", "color": "#9fc4d4"}, "fill": None},
                {"x": timestamps, "y": lowers, "type": "scatter", "name": "Lower bound",
                 "line": {"dash": "dot", "color": "#9fc4d4"}, "fill": "tonexty",
                 "fillcolor": "rgba(86,194,232,0.15)"},
            ],
            "layout": {
                "title": "Predicted Load (kW)",
                "plot_bgcolor": "#0f1b24",
                "paper_bgcolor": "#0f1b24",
                "font": {"color": "#eaf2f6"},
                "xaxis": {"title": "Time (HH:MM UTC)"},
                "yaxis": {"title": "Load (kW)"},
            },
        }

        return summary, _pretty(result), plot_data
    except Exception as e:
        return f"❌ Error: {e}", "", None


# ──────────────────────────────────────────────────────────────────────────────
# Tab 3 — Grid Telemetry
# ──────────────────────────────────────────────────────────────────────────────

def run_telemetry(substation: str) -> tuple[str, str]:
    try:
        result = get_grid_telemetry(substation)
        net = result["solar_generation_kw"] - result["load_kw"]
        balance = "🟢 Solar surplus" if net >= 0 else "🔴 Net import needed"
        summary = (
            f"**Substation: {result['substation_id']}** — `{result['timestamp'][:19]} UTC`\n\n"
            f"| Metric | Value |\n|---|---|\n"
            f"| Load | **{result['load_kw']} kW** |\n"
            f"| Solar generation | **{result['solar_generation_kw']} kW** |\n"
            f"| Battery SoC | **{result['battery_soc_pct']}%** of {result['battery_capacity_kwh']} kWh |\n"
            f"| Grid price | **${result['grid_import_price_per_kwh']:.4f}/kWh** |\n"
            f"| Net balance | {balance} ({abs(net):.1f} kW) |"
        )
        return summary, _pretty(result)
    except Exception as e:
        return f"❌ Error: {e}", ""


# ──────────────────────────────────────────────────────────────────────────────
# Tab 4 — Dispatch Optimizer
# ──────────────────────────────────────────────────────────────────────────────

def run_dispatch(
    load_kw: float,
    solar_kw: float,
    soc_pct: float,
    capacity_kwh: float,
    price: float,
    reserve_pct: float,
) -> tuple[str, str]:
    try:
        result = get_dispatch_plan(load_kw, solar_kw, soc_pct, capacity_kwh, price, reserve_pct / 100)
        summary = (
            f"**Dispatch Plan**\n\n"
            f"| Action | Value |\n|---|---|\n"
            f"| Grid import | **{result['grid_import_kw']} kW** |\n"
            f"| Battery discharge | **{result['battery_discharge_kw']} kW** |\n"
            f"| Battery charge | **{result['battery_charge_kw']} kW** |\n"
            f"| Solar curtailed | **{result['solar_curtailed_kw']} kW** |\n"
            f"| Est. cost | **${result['estimated_cost']:.4f}** |\n"
            f"| Reserve held back | **{result['reserved_battery_kwh']} kWh** |\n\n"
            f"*{result['notes']}*"
        )
        return summary, _pretty(result)
    except Exception as e:
        return f"❌ Error: {e}", ""


# ──────────────────────────────────────────────────────────────────────────────
# Tab 5 — Full Pipeline Briefing (LLM, needs GOOGLE_API_KEY)
# ──────────────────────────────────────────────────────────────────────────────

def run_briefing(region: str, lat: float, lon: float, hours: int) -> str:
    api_key = os.environ.get("GOOGLE_API_KEY", "")
    if not api_key:
        return (
            "⚠️ **GOOGLE_API_KEY not set.**\n\n"
            "This tab runs the full 4-agent LLM pipeline and needs a Google AI Studio key.\n\n"
            "**For HF Spaces deployment:** Go to your Space → Settings → Secrets "
            "and add `GOOGLE_API_KEY`.\n\n"
            "All other tabs (Climate Risk, Demand Forecast, Telemetry, Dispatch) "
            "work fully without any API key."
        )
    try:
        from gridguardian.main import run_briefing as _run_briefing
        return asyncio.run(_run_briefing(region, lat, lon, hours))
    except Exception as e:
        return f"❌ Pipeline error: {e}"


# ──────────────────────────────────────────────────────────────────────────────
# Build the app
# ──────────────────────────────────────────────────────────────────────────────

DARK_CSS = """
body, .gradio-container { background: #0f1b24 !important; color: #eaf2f6 !important; }
.gr-panel { background: #143240 !important; border-color: #3aa0c4 !important; }
h1 { color: #56c2e8 !important; }
"""

with gr.Blocks(
    title="GridGuardian AI",
    theme=gr.themes.Base(
        primary_hue="cyan",
        neutral_hue="slate",
    ),
    css=DARK_CSS,
) as demo:

    gr.Markdown(
        """
# 🔋 GridGuardian AI
**Climate-Resilient Smart Grid Multi-Agent System**  
*Kaggle AI Agents Intensive — Agents for Good track*

> Four specialist ADK agents: Climate Risk → Demand Forecast → Dispatch Optimizer → Resilience Advisor
"""
    )

    # ── Shared location picker ──────────────────────────────────────────────
    with gr.Row():
        preset = gr.Dropdown(
            list(PRESETS.keys()),
            label="📍 Location preset",
            value="Chennai, India (coastal)",
        )
        lat_in = gr.Number(value=13.08, label="Latitude", precision=4)
        lon_in = gr.Number(value=80.27, label="Longitude", precision=4)

    def apply_preset(p):
        lat, lon = PRESETS.get(p, (13.08, 80.27))
        return lat, lon

    preset.change(apply_preset, inputs=preset, outputs=[lat_in, lon_in])

    gr.Markdown("---")

    # ── Tabs ───────────────────────────────────────────────────────────────
    with gr.Tabs():

        # Tab 1 — Climate Risk
        with gr.Tab("🌊 Climate Risk"):
            gr.Markdown("Assesses heatwave, flood, storm-surge, and sea-level-rise exposure and recommends a battery reserve margin.")
            region_in = gr.Textbox(value="Coastal-North", label="Region label")
            climate_btn = gr.Button("Run Climate Risk Assessment", variant="primary")
            climate_summary = gr.Markdown()
            climate_json = gr.Code(language="json", label="Raw JSON")
            climate_btn.click(
                run_climate_risk,
                inputs=[region_in, lat_in, lon_in],
                outputs=[climate_summary, climate_json],
            )

        # Tab 2 — Demand Forecast
        with gr.Tab("📈 Demand Forecast"):
            gr.Markdown("Forecasts hourly electrical load using a bagged-regression-tree model conditioned on a real weather forecast.")
            hours_in = gr.Slider(1, 48, value=24, step=1, label="Forecast horizon (hours)")
            forecast_btn = gr.Button("Run Demand Forecast", variant="primary")
            forecast_summary = gr.Markdown()
            forecast_plot = gr.Plot(label="Load forecast chart")
            forecast_json = gr.Code(language="json", label="Raw JSON")
            forecast_btn.click(
                run_demand_forecast,
                inputs=[lat_in, lon_in, hours_in],
                outputs=[forecast_summary, forecast_json, forecast_plot],
            )

        # Tab 3 — Telemetry
        with gr.Tab("⚡ Grid Telemetry"):
            gr.Markdown("Live microgrid snapshot: load, solar generation, battery SoC, and spot price.")
            sub_in = gr.Textbox(value="SUB-01", label="Substation ID")
            telem_btn = gr.Button("Get Telemetry", variant="primary")
            telem_summary = gr.Markdown()
            telem_json = gr.Code(language="json", label="Raw JSON")
            telem_btn.click(
                run_telemetry,
                inputs=[sub_in],
                outputs=[telem_summary, telem_json],
            )

        # Tab 4 — Dispatch Optimizer
        with gr.Tab("🔌 Dispatch Optimizer"):
            gr.Markdown("Solves a least-cost linear program over grid import, battery, and solar for one time step.")
            with gr.Row():
                load_in = gr.Number(value=220, label="Load (kW)")
                solar_in = gr.Number(value=90, label="Solar available (kW)")
            with gr.Row():
                soc_in = gr.Slider(0, 100, value=60, label="Battery SoC (%)")
                cap_in = gr.Number(value=500, label="Battery capacity (kWh)")
            with gr.Row():
                price_in = gr.Number(value=0.15, label="Grid price ($/kWh)")
                reserve_in = gr.Slider(0, 40, value=20, step=1, label="Climate risk reserve (% of battery)")
            dispatch_btn = gr.Button("Optimize Dispatch", variant="primary")
            dispatch_summary = gr.Markdown()
            dispatch_json = gr.Code(language="json", label="Raw JSON")
            dispatch_btn.click(
                run_dispatch,
                inputs=[load_in, solar_in, soc_in, cap_in, price_in, reserve_in],
                outputs=[dispatch_summary, dispatch_json],
            )

        # Tab 5 — Full Pipeline Briefing
        with gr.Tab("🤖 Full Pipeline Briefing"):
            gr.Markdown(
                "Runs all four ADK agents in sequence and produces a plain-language "
                "resilience briefing. **Requires `GOOGLE_API_KEY` in Space secrets.**"
            )
            region_b = gr.Textbox(value="Coastal-North", label="Region label")
            hours_b = gr.Slider(1, 48, value=24, step=1, label="Forecast horizon (hours)")
            brief_btn = gr.Button("Run Full Agent Pipeline", variant="primary")
            brief_out = gr.Markdown()
            brief_btn.click(
                run_briefing,
                inputs=[region_b, lat_in, lon_in, hours_b],
                outputs=[brief_out],
            )

    # Footer
    gr.Markdown(
        """
---
**Tech stack:** Google ADK · FastMCP · scikit-learn · scipy · Open-Meteo API · Gradio  
[GitHub](https://github.com/your-username/gridguardian-ai) | Kaggle AI Agents Intensive Capstone
"""
    )

if __name__ == "__main__":
    demo.launch()
