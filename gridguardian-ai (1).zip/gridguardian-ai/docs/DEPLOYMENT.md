# Deployment

## Local development

```bash
git clone https://github.com/<your-username>/gridguardian-ai.git
cd gridguardian-ai
python -m venv .venv && source .venv/bin/activate
pip install -e .
cp .env.example .env   # then fill in GOOGLE_API_KEY
```

Run the CLI directly:

```bash
gridguardian telemetry --substation SUB-01
gridguardian forecast --lat 13.08 --lon 80.27 --hours 24
gridguardian dispatch --load 220 --solar 90 --soc 60 --capacity 500 --price 0.15
gridguardian briefing --region Coastal-North --lat 13.08 --lon 80.27   # requires GOOGLE_API_KEY
```

Or launch the ADK Dev UI to inspect/step through the agent pipeline:

```bash
adk web src/gridguardian/agents
# open http://localhost:8000 and select "gridguardian_orchestrator"
```

## Running the MCP server

```bash
# stdio transport (for Claude Desktop / local MCP clients)
gridguardian serve-mcp

# Streamable HTTP transport (for remote / containerized clients)
gridguardian serve-mcp --http --port 8765
```

To connect from Claude Desktop, add to its MCP config:

```json
{
  "mcpServers": {
    "gridguardian": {
      "command": "gridguardian",
      "args": ["serve-mcp"]
    }
  }
}
```

## Docker

```bash
docker build -t gridguardian-ai .
docker run --rm --env-file .env gridguardian-ai gridguardian telemetry --substation SUB-01

# or, for the long-running MCP server:
docker compose up --build
```

## CI/CD

`.github/workflows/ci.yml` runs on every push/PR: `ruff` lint, `bandit`
static security scan, and the full `pytest` suite on Python 3.11 and
3.12, followed by a Docker build sanity check.

`.github/workflows/docker-publish.yml` is a manually-triggered (or
tag-triggered) workflow that builds and pushes the image to GitHub
Container Registry. A disabled-by-default `deploy-cloud-run` job is
included as a reference for the next step — point it at a real GCP
project and service account key (`secrets.GCP_SA_KEY`,
`secrets.GCP_PROJECT_ID`) to deploy `gridguardian serve-mcp --http` as a
public Cloud Run service.

## Production hardening notes (not done in this capstone, by design)

- Swap `RateLimiter`'s in-memory token bucket for a Redis-backed limiter
  if running more than one server replica.
- Swap the synthetic climate-risk model in `data/sources.py` for a real
  NOAA/Copernicus regional dataset — the return type
  (`ClimateRiskFactors`) is already the production-shaped contract.
- Put the MCP server behind an API gateway / OAuth layer if exposing it
  beyond a trusted internal network; FastMCP supports `TokenVerifier` /
  `auth_server_provider` for this.
- Replace `InMemorySessionService` in `main.py` with a persistent
  session service (e.g. a database-backed ADK session service) for
  multi-turn operator conversations across restarts.
