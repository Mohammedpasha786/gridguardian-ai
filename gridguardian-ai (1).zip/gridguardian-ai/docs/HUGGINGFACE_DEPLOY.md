# Deploy to Hugging Face Spaces (free live demo URL)

This gives you a public `https://huggingface.co/spaces/<you>/gridguardian-ai`
URL in about 5 minutes, at zero cost.

## Steps

### 1. Create a Hugging Face account
https://huggingface.co/join (free)

### 2. Create a new Space

- Go to https://huggingface.co/new-space
- **Space name:** `gridguardian-ai`
- **License:** MIT
- **SDK:** Gradio
- **Hardware:** CPU Basic (free)
- Click **Create Space**

### 3. Upload the repo

Option A — via the HF web UI (easiest):
- In your new Space click **Files** → **Add file** → **Upload files**
- Upload everything from this repo (drag the whole folder)

Option B — via Git (recommended for version control):
```bash
# Install the HF CLI
pip install huggingface_hub

# Login
huggingface-cli login

# Clone your space and copy files in
git clone https://huggingface.co/spaces/<YOUR_USERNAME>/gridguardian-ai
cp -r /path/to/gridguardian-ai/* gridguardian-ai/
cd gridguardian-ai
git add .
git commit -m "Initial GridGuardian AI deployment"
git push
```

### 4. IMPORTANT — rename the Spaces README

HF Spaces reads `README.md` for its metadata YAML. You need to:
- Rename `README.md` → `README_REPO.md` (or delete it from the Space)
- Rename `README_SPACES.md` → `README.md`

Or just paste this at the **very top** of your existing `README.md`:
```yaml
---
title: GridGuardian AI
emoji: 🔋
colorFrom: cyan
colorTo: blue
sdk: gradio
sdk_version: "5.0"
app_file: app.py
pinned: true
license: mit
short_description: Climate-Resilient Smart Grid Multi-Agent System
---
```

### 5. Add your Google API key (for the Full Pipeline Briefing tab)

- Space → **Settings** → **Repository secrets**
- Add secret: **Name** = `GOOGLE_API_KEY`, **Value** = your key from https://aistudio.google.com/app/apikey

Tabs 1–4 (Climate Risk, Demand Forecast, Telemetry, Dispatch) work
**without** any API key — they run entirely on open APIs + synthetic data.
Only Tab 5 (Full Pipeline Briefing) needs the key.

### 6. Wait ~2 minutes for the build

HF will `pip install -r requirements.txt` and launch `app.py` automatically.
Your live URL will be:
```
https://huggingface.co/spaces/<YOUR_USERNAME>/gridguardian-ai
```

This is what you paste as the **Public Project Link** in your Kaggle submission.

## Troubleshooting

**Build fails:** Check the Space's **Logs** tab. Most common cause is a
package conflict — if you see one, pin the conflicting package version in
`requirements.txt`.

**"Module not found: gridguardian":** Make sure `src/` is in the repo root
and `app.py` is at the repo root. The `sys.path.insert(0, "src")` in
`app.py` handles this automatically.

**Tab 5 returns "GOOGLE_API_KEY not set":** Add the secret in Space
settings as described above, then restart the Space (Settings → Factory
reboot).
