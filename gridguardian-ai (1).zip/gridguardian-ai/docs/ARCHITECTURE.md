# Architecture

## Overview

GridGuardian AI is a **sequential multi-agent pipeline** built on Google's
Agent Development Kit (ADK). Four specialist `LlmAgent`s are composed into
one `SequentialAgent` (the orchestrator / `root_agent`). Each agent has a
narrow responsibility, its own tools, and writes a structured JSON result
into shared session state via `output_key`. Downstream agents read that
state through `{key}` instruction templating, so the pipeline behaves like
a typed function pipeline even though every stage is an LLM call.

```mermaid
flowchart TD
    U[Grid Operator / CLI / Cron Trigger] -->|"region, lat, lon, horizon"| O

    subgraph O[gridguardian_orchestrator — SequentialAgent]
        direction TB
        A1[climate_risk_agent] --> A2[demand_forecast_agent]
        A2 --> A3[dispatch_optimizer_agent]
        A3 --> A4[resilience_advisor_agent]
    end

    A1 -. "get_climate_risk_assessment" .-> T1[(Tools / MCP Server)]
    A2 -. "get_weather_forecast, get_demand_forecast" .-> T1
    A3 -. "get_grid_telemetry, get_dispatch_plan" .-> T1

    T1 --> D1[(Open-Meteo API\nsynthetic fallback)]
    T1 --> D2[(Synthetic climate risk\nIPCC AR6-anchored)]
    T1 --> D3[(Synthetic grid telemetry)]
    T1 --> M1[Bagged-regression-tree\ndemand model]
    T1 --> M2[scipy.optimize.linprog\ndispatch LP]

    A4 -->|Markdown resilience briefing| U

    SEC[Security layer: rate limiting,\ninput validation, audit log] -.-> T1
```

## Agents

| Agent | Tools | Reads from state | Writes to state |
|---|---|---|---|
| `climate_risk_agent` | `get_climate_risk_assessment` | — | `climate_risk_result` |
| `demand_forecast_agent` | `get_weather_forecast`, `get_demand_forecast` | — | `demand_forecast_result` |
| `dispatch_optimizer_agent` | `get_grid_telemetry`, `get_dispatch_plan` | `climate_risk_result` | `dispatch_plan_result` |
| `resilience_advisor_agent` | *(none — pure synthesis)* | all three above | `resilience_briefing` |

This is intentionally a **heterogeneous** multi-agent system: three agents
call tools and reason over real-time/forecast data, while the final agent
does pure language synthesis with zero tool access — it cannot fabricate
numbers because every figure it can cite already exists in the upstream
JSON it's shown.

## Why a pipeline instead of a single mega-agent?

1. **Separation of concerns** — the climate-risk methodology (IPCC AR6
   anchoring) and the dispatch LP formulation are genuinely different
   domains; keeping them in separate agents keeps each instruction prompt
   short, testable, and easy to swap independently (e.g. replace the
   synthetic climate model with a real NOAA/Copernicus feed without
   touching dispatch logic at all).
2. **Auditability** — every intermediate result is itself a small,
   structured JSON object, so an operator (or a unit test) can inspect
   *why* the dispatch plan reserved 20% of the battery instead of trusting
   one long, opaque chain of thought.
3. **Reuse** — the dispatch optimizer agent is generically useful even
   without climate risk (`risk_reserve_pct` defaults to 0), so it could be
   dropped into a non-climate-focused grid project unchanged.

## Tool layer / MCP server

Every tool function lives once, in `gridguardian/tools/grid_tools.py`, as a
plain type-hinted Python function with a docstring. Two different
front-ends wrap it with zero duplicated logic:

- **ADK agents** call it directly via `Agent(tools=[fn, ...])` — ADK
  introspects the function signature + docstring to build the tool schema
  the LLM sees.
- **MCP server** (`gridguardian/mcp_server/server.py`) registers the exact
  same function with `mcp.tool()(fn)` via FastMCP, so any MCP client —
  Claude Desktop, Gemini CLI, another team's ADK agent — can call into
  GridGuardian without depending on this repo's agent code at all.

This means the MCP server is not a toy add-on; it is the *real* interface
boundary, and the ADK agents are simply one specific client of it.

## Data layer: tiered fallback

`gridguardian/data/sources.py` implements the project's standard
tiered-fallback pattern:

```
Tier 1: live public API   (Open-Meteo, no key required)
   ↓ on failure / no network
Tier 2: synthetic data     (seeded, physically-structured statistical model)
```

The climate-risk function is synthetic-only today (there is no free,
key-less, real-time global API for storm-surge/SLR indices), but its
return type and the deterministic seeding mean swapping in a real
NOAA/Copernicus regional dataset later changes exactly one function
(`fetch_climate_risk`) with no change anywhere else in the system.

## Security boundary

Every public tool function calls `secure_tool_call()` (rate limit + audit
log) before doing any work, and every numeric/string argument is validated
against an explicit range/allowlist before it reaches the LP solver, the
ML model, or an outbound HTTP call. See `docs/SECURITY.md`.

## Deployability

- `Dockerfile` builds a non-root container exposing the MCP server.
- `docker-compose.yml` runs it locally on port 8765.
- `.github/workflows/ci.yml` runs lint (ruff), a static security scan
  (bandit), and the full pytest suite on every push/PR across Python
  3.11 and 3.12.
- `.github/workflows/docker-publish.yml` builds and pushes the image to
  GHCR and includes a disabled-by-default Cloud Run deploy job as a
  reference for going further.

## Antigravity (TODO before submitting)

The rubric asks you to demonstrate Antigravity **in the video**, not in
code. Before recording: open this repo in Antigravity, run `adk web`
inside it to exercise the orchestrator through the Dev UI, and capture
that as part of your screen recording. Don't claim this in the
README/Writeup unless you actually did it — judges can tell the
difference, and an honest "built primarily in VS Code, tested in
Antigravity for the demo" is a fine and truthful thing to say.
