# Security

This document covers the "Security features" key concept for the
capstone rubric. Implementation lives in
`src/gridguardian/security/controls.py`.

## 1. Secrets management

- No API key, password, or credential is ever hardcoded in source.
- `GOOGLE_API_KEY` is read only from the environment (`.env`, never
  committed — see `.gitignore`).
- `get_required_env()` fails fast with a clear message at startup
  instead of failing deep inside an agent call with a cryptic error.
- `.env.example` documents every variable the project reads, with no
  real values.

## 2. Input validation

Every value that crosses an agent/tool/MCP boundary is validated
**before** it reaches an LP solver, an ML model, or an outbound HTTP
call:

- `validate_latitude` / `validate_longitude` — bounded to valid geographic
  ranges, rejecting non-numeric input.
- `validate_percent` — bounded to `[0, 100]` (battery state of charge).
- `validate_range` — generic numeric bounds check, used for load, solar,
  battery capacity, price, and risk-reserve fraction.
- `validate_identifier` — allowlist-based string validation (alphanumeric
  + `_ -` + space only) for substation IDs and region names, so a
  malicious or malformed string can't later be interpolated into a log
  line, file path, or a future database query.

All validators raise `ValidationError`, a `ValueError` subclass, so
callers (including the LLM-driven agents, when a tool call fails) get a
structured, catchable exception rather than a raw stack trace.

## 3. Rate limiting

`RateLimiter` is an in-memory token-bucket limiter, keyed by
`(caller_id, tool_name)`, defaulting to 30 calls/minute (configurable via
`RATE_LIMIT_PER_MIN`). This protects:

- The MCP server from a runaway or misconfigured agent looping on a tool.
- Any underlying paid/rate-limited upstream API (e.g. if `fetch_weather_forecast`
  is later pointed at a metered provider) from being hammered by agent
  retries.

It is intentionally dependency-free (no Redis) for this capstone's scope;
`docs/DEPLOYMENT.md` notes how to swap it for a distributed limiter in a
multi-process deployment.

## 4. Audit logging

`audit_log_call()` logs every tool invocation with a timestamp, the
caller id, and a **SHA-256 hash of the sorted arguments** — never the raw
argument values. This means an operator can detect anomalous call
patterns (e.g. the same arguments hash repeating thousands of times in a
minute) without grid telemetry, coordinates, or other potentially
sensitive operational data ever touching a log file in plaintext.

## 5. Least-privilege tool exposure

The MCP server only registers the five read/compute tools the agents
need (`get_weather_forecast`, `get_climate_risk_assessment`,
`get_grid_telemetry`, `get_demand_forecast`, `get_dispatch_plan`). None of
them can write to a real grid control system — this capstone is
deliberately advisory-only. If GridGuardian were extended to issue actual
dispatch commands, that write path should live behind a separate,
more tightly scoped tool with its own authentication, not be added to
this read/compute tool set.

## 6. Container hardening

The `Dockerfile` creates and switches to a non-root `app` user before
running anything, and only exposes the MCP server's port.

## Reporting a vulnerability

This is a hackathon capstone project, not a production service. If you
fork this for real-world use and find a security issue, please open a
GitHub issue rather than filing it against any production grid system —
this code has not been audited for that purpose.
