"""
Security utilities for GridGuardian AI.

Implements the "Security features" key concept required by the
capstone rubric:
  1. Secrets management  -> never read API keys from code; only from
     environment variables, with a clear startup error if missing.
  2. Input validation     -> strict bounds/type checking on every value
     that crosses an agent/tool/MCP boundary, before it touches a model
     (LP solver, forecaster) or an external API call.
  3. Rate limiting        -> a simple in-memory token-bucket limiter,
     applied per tool and per caller, to protect both the MCP server
     and any upstream paid APIs from runaway agent loops.
  4. Audit logging        -> every tool invocation is logged with a
     timestamp, caller id, and a hash of arguments (not raw values, to
     avoid leaking potentially sensitive grid telemetry into logs).
"""

from __future__ import annotations

import hashlib
import logging
import os
import time
from dataclasses import dataclass
from threading import Lock

logger = logging.getLogger("gridguardian.security")
logging.basicConfig(level=logging.INFO)


# ---------------------------------------------------------------------------
# 1. Secrets management
# ---------------------------------------------------------------------------

class MissingSecretError(RuntimeError):
    pass


def get_required_env(name: str) -> str:
    """Fetch a required secret from the environment only.

    Never hardcode credentials in source. Raises a clear error at
    startup rather than failing deep inside an agent call.
    """
    value = os.environ.get(name)
    if not value:
        raise MissingSecretError(
            f"Required environment variable '{name}' is not set. "
            f"Copy .env.example to .env and fill it in, or export it "
            f"in your shell/deployment config."
        )
    return value


def get_optional_env(name: str, default: str | None = None) -> str | None:
    return os.environ.get(name, default)


# ---------------------------------------------------------------------------
# 2. Input validation
# ---------------------------------------------------------------------------

class ValidationError(ValueError):
    pass


def validate_range(value: float, *, name: str, min_value: float, max_value: float) -> float:
    if not isinstance(value, (int, float)):
        raise ValidationError(f"{name} must be numeric, got {type(value).__name__}")
    if value < min_value or value > max_value:
        raise ValidationError(
            f"{name}={value} is out of allowed range [{min_value}, {max_value}]"
        )
    return float(value)


def validate_latitude(lat: float) -> float:
    return validate_range(lat, name="latitude", min_value=-90.0, max_value=90.0)


def validate_longitude(lon: float) -> float:
    return validate_range(lon, name="longitude", min_value=-180.0, max_value=180.0)


def validate_identifier(value: str, *, name: str, max_length: int = 64) -> str:
    """Validate free-text identifiers (substation IDs, region names)
    against an allowlist pattern to prevent injection into downstream
    log strings, file paths, or future SQL/NoSQL queries.
    """
    if not isinstance(value, str) or not value:
        raise ValidationError(f"{name} must be a non-empty string")
    if len(value) > max_length:
        raise ValidationError(f"{name} exceeds max length {max_length}")
    allowed = set(
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_- "
    )
    if not set(value) <= allowed:
        raise ValidationError(f"{name} contains disallowed characters: {value!r}")
    return value


def validate_percent(value: float, *, name: str) -> float:
    return validate_range(value, name=name, min_value=0.0, max_value=100.0)


# ---------------------------------------------------------------------------
# 3. Rate limiting (token bucket, per caller + tool)
# ---------------------------------------------------------------------------

@dataclass
class _Bucket:
    tokens: float
    last_refill: float


class RateLimiter:
    """Thread-safe in-memory token-bucket rate limiter.

    Default: 30 calls/minute/tool/caller, refilled continuously. This is
    intentionally simple and dependency-free; swap for a Redis-backed
    limiter for multi-process deployments.
    """

    def __init__(self, max_calls_per_minute: int = 30):
        self.capacity = max_calls_per_minute
        self.refill_rate = max_calls_per_minute / 60.0  # tokens per second
        self._buckets: dict[str, _Bucket] = {}
        self._lock = Lock()

    def _key(self, caller_id: str, tool_name: str) -> str:
        return f"{caller_id}:{tool_name}"

    def allow(self, caller_id: str, tool_name: str) -> bool:
        key = self._key(caller_id, tool_name)
        now = time.monotonic()
        with self._lock:
            bucket = self._buckets.get(key)
            if bucket is None:
                bucket = _Bucket(tokens=self.capacity - 1, last_refill=now)
                self._buckets[key] = bucket
                return True
            elapsed = now - bucket.last_refill
            bucket.tokens = min(self.capacity, bucket.tokens + elapsed * self.refill_rate)
            bucket.last_refill = now
            if bucket.tokens >= 1:
                bucket.tokens -= 1
                return True
            return False


class RateLimitExceeded(RuntimeError):
    pass


_default_limiter = RateLimiter(max_calls_per_minute=int(os.environ.get("RATE_LIMIT_PER_MIN", "30")))


def enforce_rate_limit(caller_id: str, tool_name: str) -> None:
    if not _default_limiter.allow(caller_id, tool_name):
        logger.warning("Rate limit exceeded for caller=%s tool=%s", caller_id, tool_name)
        raise RateLimitExceeded(
            f"Rate limit exceeded for '{tool_name}'. Please slow down requests."
        )


# ---------------------------------------------------------------------------
# 4. Audit logging
# ---------------------------------------------------------------------------

def audit_log_call(caller_id: str, tool_name: str, kwargs: dict) -> None:
    """Log a tool invocation without leaking raw argument values.

    A SHA-256 digest of the sorted kwargs is logged instead of the raw
    values, so audit trails can detect repeated/anomalous call patterns
    without ever persisting potentially sensitive grid telemetry,
    coordinates, or identifiers in plaintext logs.
    """
    serialized = "&".join(f"{k}={kwargs[k]}" for k in sorted(kwargs))
    digest = hashlib.sha256(serialized.encode("utf-8")).hexdigest()[:16]
    logger.info(
        "AUDIT caller=%s tool=%s args_hash=%s ts=%.3f",
        caller_id,
        tool_name,
        digest,
        time.time(),
    )


def secure_tool_call(caller_id: str, tool_name: str, kwargs: dict) -> None:
    """Convenience wrapper combining rate limiting + audit logging.
    Call at the top of every public tool function.
    """
    enforce_rate_limit(caller_id, tool_name)
    audit_log_call(caller_id, tool_name, kwargs)
