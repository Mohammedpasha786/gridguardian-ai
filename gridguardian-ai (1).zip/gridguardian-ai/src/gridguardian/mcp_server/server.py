"""
GridGuardian MCP Server.

Exposes the same tool functions used internally by the ADK agents
(gridguardian.tools.grid_tools) as a standalone MCP server, so any
MCP-compatible client -- Claude Desktop, the ADK MCPToolset, a Gemini
CLI extension, or another team's agent -- can call into GridGuardian's
weather, climate-risk, telemetry, forecasting, and optimization
capabilities without depending on this repo's agent code at all.

Run:
    python -m gridguardian.mcp_server.server                 # stdio transport
    python -m gridguardian.mcp_server.server --http --port 8765  # Streamable HTTP

Security note: this server applies the same rate limiting + input
validation as the in-process tools (see security/controls.py), since an
MCP server is a network-reachable trust boundary and must defend itself
independently of whatever calls it.
"""

from __future__ import annotations

import argparse

from mcp.server.fastmcp import FastMCP

from gridguardian.tools.grid_tools import (
    get_climate_risk_assessment,
    get_demand_forecast,
    get_dispatch_plan,
    get_grid_telemetry,
    get_weather_forecast,
)

mcp = FastMCP(
    name="gridguardian",
    instructions=(
        "Tools for climate-resilient smart-grid planning: weather forecasts, "
        "long-horizon climate risk indicators, real-time microgrid telemetry, "
        "demand forecasting, and least-cost dispatch optimization with an "
        "optional climate-risk battery reserve margin."
    ),
)

# Register the shared tool implementations directly -- FastMCP introspects
# each function's type hints and docstring to build its MCP tool schema,
# so there is exactly one source of truth for behavior and one for schema.
mcp.tool()(get_weather_forecast)
mcp.tool()(get_climate_risk_assessment)
mcp.tool()(get_grid_telemetry)
mcp.tool()(get_demand_forecast)
mcp.tool()(get_dispatch_plan)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the GridGuardian MCP server.")
    parser.add_argument("--http", action="store_true", help="Use Streamable HTTP transport instead of stdio")
    parser.add_argument("--port", type=int, default=8765, help="Port for HTTP transport")
    args = parser.parse_args()

    if args.http:
        mcp.settings.port = args.port
        mcp.run(transport="streamable-http")
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
