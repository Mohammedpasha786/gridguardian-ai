"""
Least-cost dispatch optimization for a solar + battery + grid-import
microgrid, with a climate-risk-aware reserve margin.

Formulated as a linear program solved with scipy.optimize.linprog,
mirroring the dispatch-optimization module of the IEMS smart-grid
project. The novel piece for GridGuardian is `risk_reserve_pct`: when
the Climate Risk Agent flags elevated storm/flood/heatwave risk, the
optimizer is instructed to hold back additional battery reserve so the
microgrid can island itself if the grid connection is interrupted.
"""

from __future__ import annotations

from dataclasses import dataclass

from scipy.optimize import linprog


@dataclass
class DispatchPlan:
    grid_import_kw: float
    battery_discharge_kw: float
    battery_charge_kw: float
    solar_curtailed_kw: float
    estimated_cost: float
    reserved_battery_kwh: float
    notes: str


def optimize_dispatch(
    load_kw: float,
    solar_available_kw: float,
    battery_soc_pct: float,
    battery_capacity_kwh: float,
    grid_price_per_kwh: float,
    risk_reserve_pct: float = 0.0,
    max_battery_power_kw: float = 100.0,
    max_grid_import_kw: float = 400.0,
) -> DispatchPlan:
    """Solve a one-step least-cost dispatch LP.

    Decision variables x = [grid_import, batt_discharge, batt_charge, solar_curtail]
    (all >= 0, kW).

    Objective: minimize grid_price * grid_import
               + small_penalty * batt_discharge   (battery cycling cost)
               + large_penalty * solar_curtail     (discourage wasting clean energy)

    Constraint: grid_import + batt_discharge + (solar_available - solar_curtail)
                - batt_charge == load_kw   (power balance)

    Bounds respect available battery energy above the climate-risk
    reserve floor, and the inverter/import power ratings.
    """
    battery_energy_kwh = battery_capacity_kwh * (battery_soc_pct / 100.0)
    reserved_kwh = battery_capacity_kwh * max(0.0, min(risk_reserve_pct, 0.9))
    usable_kwh = max(0.0, battery_energy_kwh - reserved_kwh)
    max_discharge_kw = min(max_battery_power_kw, usable_kwh)  # 1-hour step approximation
    headroom_kwh = max(0.0, battery_capacity_kwh - battery_energy_kwh)
    max_charge_kw = min(max_battery_power_kw, headroom_kwh)

    battery_cycle_cost = 0.02  # $/kWh wear cost, discourages needless cycling
    curtailment_penalty = 5.0  # $/kWh, strongly discourages wasting solar

    c = [grid_price_per_kwh, battery_cycle_cost, 1e-4, curtailment_penalty]

    a_eq = [[1, 1, -1, -1]]
    b_eq = [load_kw - solar_available_kw]

    bounds = [
        (0, max_grid_import_kw),
        (0, max_discharge_kw),
        (0, max_charge_kw),
        (0, solar_available_kw),
    ]

    result = linprog(c=c, A_eq=a_eq, b_eq=b_eq, bounds=bounds, method="highs")

    if not result.success:
        # Infeasible (e.g., demand exceeds all available supply + import cap):
        # fall back to a safe degraded plan that imports at the cap and
        # reports the shortfall rather than raising, since operators need
        # an actionable plan even in extreme scenarios.
        grid_import = max_grid_import_kw
        shortfall = max(0.0, load_kw - solar_available_kw - grid_import)
        return DispatchPlan(
            grid_import_kw=round(grid_import, 2),
            battery_discharge_kw=round(min(max_discharge_kw, max(0.0, shortfall)), 2),
            battery_charge_kw=0.0,
            solar_curtailed_kw=0.0,
            estimated_cost=round(grid_import * grid_price_per_kwh, 2),
            reserved_battery_kwh=round(reserved_kwh, 2),
            notes=(
                f"LP infeasible at requested bounds; degraded plan applied. "
                f"Residual unmet load: {round(shortfall, 1)} kW. Consider load shedding."
            ),
        )

    grid_import, batt_discharge, batt_charge, curtail = result.x
    return DispatchPlan(
        grid_import_kw=round(float(grid_import), 2),
        battery_discharge_kw=round(float(batt_discharge), 2),
        battery_charge_kw=round(float(batt_charge), 2),
        solar_curtailed_kw=round(float(curtail), 2),
        estimated_cost=round(float(result.fun), 4),
        reserved_battery_kwh=round(reserved_kwh, 2),
        notes="Optimal solution found." if risk_reserve_pct == 0 else (
            f"Optimal solution found with {risk_reserve_pct*100:.0f}% climate-risk "
            f"battery reserve held back ({round(reserved_kwh,1)} kWh) for islanding capability."
        ),
    )
