"""
Short-horizon electrical demand forecasting for a microgrid.

Primary model: bagged regression trees (RandomForestRegressor), trained
on engineered time + weather features. This mirrors the approach used in
the IEMS smart-grid project (bagged trees as the default, with an
optional deep model for longer horizons).

The model is trained lazily on synthetic-but-physically-structured
historical data on first use and cached in-process, so the agent works
out of the box with no external dataset or training pipeline required.
A real deployment would swap `_build_training_frame` for a query against
historical AMI/SCADA data.
"""

from __future__ import annotations

import datetime as dt
import math
from dataclasses import dataclass
from functools import lru_cache

import numpy as np
from sklearn.ensemble import RandomForestRegressor

from gridguardian.data.sources import WeatherPoint, _seeded_rng


@dataclass
class ForecastPoint:
    timestamp: str
    predicted_load_kw: float
    lower_bound_kw: float
    upper_bound_kw: float


def _build_training_frame(n_days: int = 90) -> tuple[np.ndarray, np.ndarray]:
    """Synthesize n_days of hourly (feature, load) training pairs.

    Features: [hour_sin, hour_cos, day_of_week, temperature_c, is_weekend]
    Target: load_kw, generated from a diurnal/weekly seasonal pattern with
    temperature-driven cooling load and Gaussian noise -- structurally
    similar to real residential/light-commercial feeders.
    """
    rng = _seeded_rng("training-frame")
    rows = []
    targets = []
    start = dt.datetime(2024, 1, 1)
    for h in range(n_days * 24):
        ts = start + dt.timedelta(hours=h)
        hour = ts.hour
        dow = ts.weekday()
        is_weekend = 1.0 if dow >= 5 else 0.0
        temp = 24 + 8 * math.sin((hour - 9) / 24 * 2 * math.pi) + rng.uniform(-2, 2)
        base = 180 + 70 * math.sin((hour - 8) / 24 * 2 * math.pi)
        weekly = -25 * is_weekend
        cooling_load = max(0.0, (temp - 26)) * 6.0
        noise = rng.gauss(0, 8)
        load = max(15.0, base + weekly + cooling_load + noise)
        rows.append(
            [
                math.sin(hour / 24 * 2 * math.pi),
                math.cos(hour / 24 * 2 * math.pi),
                float(dow),
                temp,
                is_weekend,
            ]
        )
        targets.append(load)
    return np.array(rows), np.array(targets)


@lru_cache(maxsize=1)
def _get_model() -> RandomForestRegressor:
    x_train, y_train = _build_training_frame()
    model = RandomForestRegressor(
        n_estimators=120,
        max_depth=10,
        min_samples_leaf=3,
        random_state=7,
        n_jobs=-1,
    )
    model.fit(x_train, y_train)
    return model


def forecast_demand(
    weather: list[WeatherPoint], start_dow: int | None = None
) -> list[ForecastPoint]:
    """Forecast hourly load for each provided weather point.

    Args:
        weather: list of WeatherPoint, one per forecast hour, in order.
        start_dow: ISO weekday (0=Mon) of the first point. Defaults to
            today's weekday if not provided.

    Returns:
        List of ForecastPoint with point estimate and a +/-10%
        uncertainty band derived from the ensemble's tree-to-tree
        variance (a cheap proxy for a true prediction interval).
    """
    model = _get_model()
    dow0 = start_dow if start_dow is not None else dt.datetime.now(dt.timezone.utc).weekday()
    features = []
    for i, wp in enumerate(weather):
        ts = dt.datetime.fromisoformat(wp.timestamp.replace("Z", ""))
        hour = ts.hour
        dow = (dow0 + (i // 24)) % 7
        is_weekend = 1.0 if dow >= 5 else 0.0
        features.append(
            [
                math.sin(hour / 24 * 2 * math.pi),
                math.cos(hour / 24 * 2 * math.pi),
                float(dow),
                wp.temperature_c,
                is_weekend,
            ]
        )
    x = np.array(features)
    per_tree = np.stack([tree.predict(x) for tree in model.estimators_], axis=0)
    mean_pred = per_tree.mean(axis=0)
    std_pred = per_tree.std(axis=0)

    results = []
    for i, wp in enumerate(weather):
        results.append(
            ForecastPoint(
                timestamp=wp.timestamp,
                predicted_load_kw=round(float(mean_pred[i]), 2),
                lower_bound_kw=round(float(max(0.0, mean_pred[i] - 1.6 * std_pred[i])), 2),
                upper_bound_kw=round(float(mean_pred[i] + 1.6 * std_pred[i]), 2),
            )
        )
    return results
