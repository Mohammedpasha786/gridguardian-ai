"""
Tool functions for GridGuardian AI.

Every function here is a plain, type-hinted Python function with a
docstring -- this is the format both:
  - Google ADK's `Agent(tools=[...])` auto-wraps into LLM-callable tools, and
  - the MCP server (mcp_server/server.py) exposes via `@mcp.tool()`.

Keeping one implementation shared by both keeps agent behavior and the
standalone MCP server in sync with no duplicated logic.

Every function validates its inputs and goes through the security
boundary (`secure_tool_call`) before doing any real work, per
docs/SECURITY.md.
"""

from __future__ import annotations

from gridguardian.data.sources import fetch_weather_forecast, fetch_climate_risk, get_grid_state
from gridguardian.dispatch_optimizer import optimize_dispatch
from gridguardian.forecasting import forecast_demand
from gridguardian.security.controls import (
    secure_tool_call,
    validate_identifier,
    validate_latitude,
    validate_longitude,
    validate_percent,
    validate_range,
)


def get_weather_forecast(latitude: float, longitude: float, hours: int = 48) -> dict:
    """Get an hourly weather forecast for a location.

    Args:
        latitude: Latitude in decimal degrees (-90 to 90).
        longitude: Longitude in decimal degrees (-180 to 180).
        hours: Number of forecast hours to return (1-168).

    Returns:
        A dict with a 'points' list of hourly weather records
        (timestamp, temperature_c, cloud_cover_pct, wind_speed_ms,
        precipitation_mm, source).
    """
    secure_tool_call("agent", "get_weather_forecast", {"latitude": latitude, "longitude": longitude, "hours": hours})
    lat = validate_latitude(latitude)
    lon = validate_longitude(longitude)
    hrs = int(validate_range(hours, name="hours", min_value=1, max_value=168))
    points = fetch_weather_forecast(lat, lon, hrs)
    return {"points": [vars(p) for p in points]}


def get_climate_risk_assessment(region: str, latitude: float, longitude: float) -> dict:
    """Get long-horizon climate risk indicators for a region.

    Args:
        region: Human-readable region/substation name, e.g. 'Coastal-North'.
        latitude: Latitude in decimal degrees (-90 to 90).
        longitude: Longitude in decimal degrees (-180 to 180).

    Returns:
        A dict with heatwave_probability, flood_risk_index,
        storm_surge_risk_index, sea_level_rise_mm_per_yr,
        extreme_event_trend_pct, source, and notes.
    """
    secure_tool_call(
        "agent", "get_climate_risk_assessment",
        {"region": region, "latitude": latitude, "longitude": longitude},
    )
    region_v = validate_identifier(region, name="region")
    lat = validate_latitude(latitude)
    lon = validate_longitude(longitude)
    risk = fetch_climate_risk(region_v, lat, lon)
    return vars(risk)


def get_grid_telemetry(substation_id: str = "SUB-01") -> dict:
    """Get current real-time microgrid telemetry for a substation.

    Args:
        substation_id: Identifier of the substation/microgrid to query.

    Returns:
        A dict with timestamp, load_kw, solar_generation_kw,
        battery_soc_pct, battery_capacity_kwh, grid_import_price_per_kwh,
        substation_id.
    """
    secure_tool_call("agent", "get_grid_telemetry", {"substation_id": substation_id})
    sub_id = validate_identifier(substation_id, name="substation_id")
    state = get_grid_state(sub_id)
    return vars(state)


def get_demand_forecast(latitude: float, longitude: float, hours: int = 48) -> dict:
    """Forecast hourly electrical demand (load) for a microgrid location.

    Internally fetches a weather forecast for the location and runs it
    through a bagged-regression-tree demand model trained on seasonal
    load patterns.

    Args:
        latitude: Latitude in decimal degrees (-90 to 90).
        longitude: Longitude in decimal degrees (-180 to 180).
        hours: Number of hours to forecast (1-168).

    Returns:
        A dict with a 'forecast' list of hourly records (timestamp,
        predicted_load_kw, lower_bound_kw, upper_bound_kw).
    """
    secure_tool_call(
        "agent", "get_demand_forecast",
        {"latitude": latitude, "longitude": longitude, "hours": hours},
    )
    lat = validate_latitude(latitude)
    lon = validate_longitude(longitude)
    hrs = int(validate_range(hours, name="hours", min_value=1, max_value=168))
    weather = fetch_weather_forecast(lat, lon, hrs)
    forecast = forecast_demand(weather)
    return {"forecast": [vars(f) for f in forecast]}


def get_dispatch_plan(
    load_kw: float,
    solar_available_kw: float,
    battery_soc_pct: float,
    battery_capacity_kwh: float,
    grid_price_per_kwh: float,
    risk_reserve_pct: float = 0.0,
) -> dict:
    """Compute the least-cost dispatch plan for one time step.

    Solves a linear program over grid import, battery charge/discharge,
    and solar curtailment to meet `load_kw` at minimum cost, optionally
    holding back `risk_reserve_pct` of battery capacity for resilience
    against an elevated climate risk (storms, flooding, heatwaves).

    Args:
        load_kw: Forecast or measured load in kW.
        solar_available_kw: Available solar generation in kW.
        battery_soc_pct: Current battery state of charge, 0-100.
        battery_capacity_kwh: Total battery energy capacity in kWh.
        grid_price_per_kwh: Current grid import price in $/kWh.
        risk_reserve_pct: Fraction (0-0.9) of battery capacity to
            reserve for islanding/backup due to climate risk.

    Returns:
        A dict with grid_import_kw, battery_discharge_kw,
        battery_charge_kw, solar_curtailed_kw, estimated_cost,
        reserved_battery_kwh, notes.
    """
    secure_tool_call(
        "agent", "get_dispatch_plan",
        {
            "load_kw": load_kw,
            "solar_available_kw": solar_available_kw,
            "battery_soc_pct": battery_soc_pct,
            "battery_capacity_kwh": battery_capacity_kwh,
            "grid_price_per_kwh": grid_price_per_kwh,
            "risk_reserve_pct": risk_reserve_pct,
        },
    )
    load = validate_range(load_kw, name="load_kw", min_value=0, max_value=100000)
    solar = validate_range(solar_available_kw, name="solar_available_kw", min_value=0, max_value=100000)
    soc = validate_percent(battery_soc_pct, name="battery_soc_pct")
    capacity = validate_range(battery_capacity_kwh, name="battery_capacity_kwh", min_value=1, max_value=1000000)
    price = validate_range(grid_price_per_kwh, name="grid_price_per_kwh", min_value=0, max_value=100)
    reserve = validate_range(risk_reserve_pct, name="risk_reserve_pct", min_value=0, max_value=0.9)
    plan = optimize_dispatch(
        load_kw=load,
        solar_available_kw=solar,
        battery_soc_pct=soc,
        battery_capacity_kwh=capacity,
        grid_price_per_kwh=price,
        risk_reserve_pct=reserve,
    )
    return vars(plan)
