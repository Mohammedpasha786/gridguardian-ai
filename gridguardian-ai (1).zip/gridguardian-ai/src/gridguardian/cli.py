"""
GridGuardian CLI -- packaged as the project's "agent skill": a single
`gridguardian` command operators and CI pipelines can invoke directly,
without needing to know anything about ADK, MCP, or the underlying
Python modules.

Examples:
    gridguardian weather --lat 13.08 --lon 80.27
    gridguardian climate-risk --region Coastal-North --lat 13.08 --lon 80.27
    gridguardian telemetry --substation SUB-01
    gridguardian forecast --lat 13.08 --lon 80.27 --hours 24
    gridguardian dispatch --load 220 --solar 90 --soc 60 --capacity 500 --price 0.15
    gridguardian briefing --region Coastal-North --lat 13.08 --lon 80.27
    gridguardian serve-mcp --http --port 8765
"""

from __future__ import annotations

import asyncio
import json

import click

from gridguardian.tools.grid_tools import (
    get_climate_risk_assessment,
    get_demand_forecast,
    get_dispatch_plan,
    get_grid_telemetry,
    get_weather_forecast,
)


@click.group()
def cli() -> None:
    """GridGuardian AI -- climate-resilient smart grid agent toolkit."""


@cli.command()
@click.option("--lat", type=float, required=True, help="Latitude")
@click.option("--lon", type=float, required=True, help="Longitude")
@click.option("--hours", type=int, default=48, help="Forecast horizon in hours")
def weather(lat: float, lon: float, hours: int) -> None:
    """Fetch an hourly weather forecast."""
    click.echo(json.dumps(get_weather_forecast(lat, lon, hours), indent=2))


@cli.command(name="climate-risk")
@click.option("--region", required=True, help="Region/substation label")
@click.option("--lat", type=float, required=True, help="Latitude")
@click.option("--lon", type=float, required=True, help="Longitude")
def climate_risk(region: str, lat: float, lon: float) -> None:
    """Assess long-horizon climate risk for a region."""
    click.echo(json.dumps(get_climate_risk_assessment(region, lat, lon), indent=2))


@cli.command()
@click.option("--substation", default="SUB-01", help="Substation/microgrid ID")
def telemetry(substation: str) -> None:
    """Get current microgrid telemetry."""
    click.echo(json.dumps(get_grid_telemetry(substation), indent=2))


@cli.command()
@click.option("--lat", type=float, required=True, help="Latitude")
@click.option("--lon", type=float, required=True, help="Longitude")
@click.option("--hours", type=int, default=48, help="Forecast horizon in hours")
def forecast(lat: float, lon: float, hours: int) -> None:
    """Forecast electrical demand for a location."""
    click.echo(json.dumps(get_demand_forecast(lat, lon, hours), indent=2))


@cli.command()
@click.option("--load", "load_kw", type=float, required=True, help="Load in kW")
@click.option("--solar", "solar_kw", type=float, required=True, help="Available solar in kW")
@click.option("--soc", "soc_pct", type=float, required=True, help="Battery state of charge, %")
@click.option("--capacity", "capacity_kwh", type=float, required=True, help="Battery capacity, kWh")
@click.option("--price", "price_per_kwh", type=float, required=True, help="Grid price, $/kWh")
@click.option("--reserve", "risk_reserve_pct", type=float, default=0.0, help="Climate-risk reserve fraction, 0-0.9")
def dispatch(load_kw, solar_kw, soc_pct, capacity_kwh, price_per_kwh, risk_reserve_pct) -> None:
    """Compute a least-cost dispatch plan."""
    plan = get_dispatch_plan(load_kw, solar_kw, soc_pct, capacity_kwh, price_per_kwh, risk_reserve_pct)
    click.echo(json.dumps(plan, indent=2))


@cli.command()
@click.option("--region", required=True, help="Region/substation label")
@click.option("--lat", type=float, required=True, help="Latitude")
@click.option("--lon", type=float, required=True, help="Longitude")
@click.option("--hours", type=int, default=24, help="Forecast horizon in hours")
def briefing(region: str, lat: float, lon: float, hours: int) -> None:
    """Run the full multi-agent pipeline and print the resilience briefing.

    Requires GOOGLE_API_KEY to be set, since this invokes the LLM-backed
    ADK agents rather than calling tool functions directly.
    """
    from gridguardian.main import run_briefing

    click.echo(asyncio.run(run_briefing(region, lat, lon, hours)))


@cli.command(name="serve-mcp")
@click.option("--http", is_flag=True, help="Use Streamable HTTP transport instead of stdio")
@click.option("--port", type=int, default=8765, help="Port for HTTP transport")
def serve_mcp(http: bool, port: int) -> None:
    """Start the GridGuardian MCP server."""
    from gridguardian.mcp_server.server import mcp

    if http:
        mcp.settings.port = port
        mcp.run(transport="streamable-http")
    else:
        mcp.run(transport="stdio")


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
