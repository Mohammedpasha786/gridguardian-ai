"""
Programmatic entry point for running the GridGuardian multi-agent
pipeline outside of `adk web` / `adk run`.

Requires a GOOGLE_API_KEY (or Vertex AI credentials) in the environment
-- see .env.example. This module never reads the key itself; ADK's
model client reads it from the environment, consistent with the
secrets-management policy in security/controls.py.
"""

from __future__ import annotations

import asyncio
import uuid

from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from gridguardian.agents.orchestrator import root_agent

APP_NAME = "gridguardian"


async def run_briefing(region: str, latitude: float, longitude: float, hours: int = 24) -> str:
    """Run the full pipeline once and return the final resilience briefing."""
    session_service = InMemorySessionService()
    user_id = "operator"
    session_id = str(uuid.uuid4())
    await session_service.create_session(app_name=APP_NAME, user_id=user_id, session_id=session_id)

    runner = Runner(app_name=APP_NAME, agent=root_agent, session_service=session_service)

    prompt = (
        f"Region: {region}\n"
        f"Latitude: {latitude}\n"
        f"Longitude: {longitude}\n"
        f"Forecast horizon: {hours} hours\n"
        "Run the full climate-resilience and dispatch assessment for this "
        "microgrid and produce the resilience briefing."
    )
    message = types.Content(role="user", parts=[types.Part(text=prompt)])

    final_text = ""
    async for event in runner.run_async(user_id=user_id, session_id=session_id, new_message=message):
        if event.content and event.content.parts:
            for part in event.content.parts:
                if getattr(part, "text", None):
                    final_text = part.text

    return final_text


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Run the GridGuardian resilience pipeline once.")
    parser.add_argument("--region", default="Coastal-North", help="Region/substation label")
    parser.add_argument("--lat", type=float, default=13.0827, help="Latitude")
    parser.add_argument("--lon", type=float, default=80.2707, help="Longitude")
    parser.add_argument("--hours", type=int, default=24, help="Forecast horizon in hours")
    args = parser.parse_args()

    result = asyncio.run(run_briefing(args.region, args.lat, args.lon, args.hours))
    print(result)


if __name__ == "__main__":
    main()
