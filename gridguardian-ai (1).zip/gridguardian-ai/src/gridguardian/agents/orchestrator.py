"""GridGuardian Orchestrator.

Wires the four specialist agents into a single multi-agent pipeline
using ADK's `SequentialAgent`:

    climate_risk_agent -> demand_forecast_agent -> dispatch_optimizer_agent -> resilience_advisor_agent

Each agent writes its structured result into shared session state via
`output_key`, and downstream agents read prior results through
`{key}` instruction templating. This is the "root agent" ADK tooling
(adk web / adk run / Dev UI) looks for by convention.
"""

from __future__ import annotations

from google.adk.agents import SequentialAgent

from gridguardian.agents.climate_risk_agent import climate_risk_agent
from gridguardian.agents.demand_forecast_agent import demand_forecast_agent
from gridguardian.agents.dispatch_optimizer_agent import dispatch_optimizer_agent
from gridguardian.agents.resilience_advisor_agent import resilience_advisor_agent

root_agent = SequentialAgent(
    name="gridguardian_orchestrator",
    description=(
        "Climate-resilient smart grid advisory pipeline: assesses climate "
        "risk, forecasts demand, optimizes dispatch, and synthesizes a "
        "human-readable resilience briefing for grid operators."
    ),
    sub_agents=[
        climate_risk_agent,
        demand_forecast_agent,
        dispatch_optimizer_agent,
        resilience_advisor_agent,
    ],
)
