"""Resilience Advisor Agent.

The final synthesis step of the GridGuardian pipeline. Has no tools of
its own -- it purely reasons over the structured outputs produced by
the three upstream specialist agents (held in session state) and
produces a single, operator-facing resilience briefing. This is also
the agent the human operator actually reads, so it is instructed to
write in plain, non-technical language and to be explicit about action
items, consistent with SDG 7 (Affordable & Clean Energy) and SDG 13
(Climate Action) goals.
"""

from __future__ import annotations

from google.adk.agents import LlmAgent

MODEL = "gemini-2.5-flash"

resilience_advisor_agent = LlmAgent(
    name="resilience_advisor_agent",
    model=MODEL,
    description=(
        "Synthesizes climate risk, demand forecast, and dispatch plan into a "
        "single operator-facing resilience briefing."
    ),
    instruction=(
        "You are GridGuardian's resilience advisor, writing for a grid "
        "operator who needs to make a decision in the next few minutes.\n\n"
        "Inputs (JSON produced by upstream specialist agents):\n"
        "Climate risk: {climate_risk_result}\n"
        "Demand forecast: {demand_forecast_result}\n"
        "Dispatch plan: {dispatch_plan_result}\n\n"
        "Write a concise briefing in Markdown with these sections:\n"
        "## Resilience Briefing\n"
        "- **Headline** (one sentence: is everything normal, or is action needed?)\n"
        "- **Climate Outlook** (2-3 sentences, plain language, no jargon)\n"
        "- **Demand Outlook** (2-3 sentences: expected peak and timing)\n"
        "- **Dispatch Recommendation** (2-3 sentences: what the system will do "
        "and why, including any battery reserve held back for resilience)\n"
        "- **Action Items** (a short bulleted list, only if any reserve was "
        "held back, the LP was infeasible, or risk indices are elevated; "
        "otherwise write 'No action required.')\n\n"
        "Be specific with numbers from the inputs. Do not invent data that "
        "is not present in the inputs above. Keep the whole briefing under "
        "200 words."
    ),
    tools=[],
    output_key="resilience_briefing",
)
