"""Climate Risk Agent.

Assesses long-horizon climate threats (heatwaves, flooding, storm surge,
sea-level rise) for a given grid region, drawing on the methodology from
the coastline-prediction climate project (NOAA/Copernicus-style hazard
indicators anchored to IPCC AR6 scenarios). Its output feeds the
Dispatch Optimizer Agent's reserve-margin decision.
"""

from __future__ import annotations

from google.adk.agents import LlmAgent

from gridguardian.tools.grid_tools import get_climate_risk_assessment

MODEL = "gemini-2.5-flash"

climate_risk_agent = LlmAgent(
    name="climate_risk_agent",
    model=MODEL,
    description=(
        "Assesses long-horizon climate risk (heatwave, flood, storm surge, "
        "sea-level rise) for a grid region and recommends a battery reserve "
        "margin for resilience."
    ),
    instruction=(
        "You are a climate-risk analyst for electrical grid infrastructure.\n"
        "Given a region name and coordinates, call `get_climate_risk_assessment` "
        "exactly once to retrieve heatwave_probability, flood_risk_index, "
        "storm_surge_risk_index, sea_level_rise_mm_per_yr, and extreme_event_trend_pct.\n\n"
        "Then derive a single number `risk_reserve_pct` between 0.0 and 0.4 "
        "representing how much battery capacity (as a fraction) the grid "
        "operator should hold back for islanding/backup power, using this rule "
        "of thumb: \n"
        "  risk_reserve_pct = 0.4 * max(flood_risk_index, storm_surge_risk_index, heatwave_probability)\n"
        "Clamp the result to [0.0, 0.4].\n\n"
        "Respond ONLY with a compact JSON object with keys: "
        "region, heatwave_probability, flood_risk_index, storm_surge_risk_index, "
        "sea_level_rise_mm_per_yr, extreme_event_trend_pct, risk_reserve_pct, "
        "and a one-sentence 'summary' explaining the dominant hazard. "
        "Do not include any text outside the JSON object."
    ),
    tools=[get_climate_risk_assessment],
    output_key="climate_risk_result",
)
