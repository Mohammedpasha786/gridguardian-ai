"""Demand Forecast Agent.

Forecasts short-horizon electrical demand for a microgrid location using
a bagged-regression-tree model conditioned on a weather forecast,
mirroring the forecasting module of the IEMS smart-grid project.
"""

from __future__ import annotations

from google.adk.agents import LlmAgent

from gridguardian.tools.grid_tools import get_demand_forecast, get_weather_forecast

MODEL = "gemini-2.5-flash"

demand_forecast_agent = LlmAgent(
    name="demand_forecast_agent",
    model=MODEL,
    description=(
        "Forecasts short-horizon electrical load for a microgrid location "
        "based on weather-conditioned historical demand patterns."
    ),
    instruction=(
        "You are a load-forecasting specialist for electrical microgrids.\n"
        "Given a latitude, longitude, and horizon in hours, call "
        "`get_demand_forecast` exactly once with those coordinates.\n\n"
        "Summarize the result as compact JSON with keys: "
        "peak_load_kw (the maximum predicted_load_kw across the horizon), "
        "peak_time (the timestamp of that peak), "
        "average_load_kw (mean across the horizon, rounded to 1 decimal), "
        "and 'summary' (one sentence describing the demand pattern, e.g. "
        "whether a heat-driven afternoon peak is expected). "
        "Do not include any text outside the JSON object."
    ),
    tools=[get_weather_forecast, get_demand_forecast],
    output_key="demand_forecast_result",
)
