"""Dispatch Optimizer Agent.

Computes the least-cost solar + battery + grid dispatch plan, holding
back battery reserve in proportion to the climate-risk margin computed
upstream by the Climate Risk Agent, and sized against the peak load
computed upstream by the Demand Forecast Agent. Mirrors the dispatch
module of the IEMS smart-grid project, with a climate-resilience twist.
"""

from __future__ import annotations

from google.adk.agents import LlmAgent

from gridguardian.tools.grid_tools import get_dispatch_plan, get_grid_telemetry

MODEL = "gemini-2.5-flash"

dispatch_optimizer_agent = LlmAgent(
    name="dispatch_optimizer_agent",
    model=MODEL,
    description=(
        "Computes a least-cost solar/battery/grid dispatch plan, applying a "
        "climate-risk-aware battery reserve margin."
    ),
    instruction=(
        "You are a microgrid dispatch optimizer.\n\n"
        "Context from earlier agents in this pipeline:\n"
        "Climate risk assessment: {climate_risk_result}\n"
        "Demand forecast: {demand_forecast_result}\n\n"
        "Steps:\n"
        "1. Call `get_grid_telemetry` to get the current real-time state "
        "(load_kw, solar_generation_kw, battery_soc_pct, battery_capacity_kwh, "
        "grid_import_price_per_kwh).\n"
        "2. Extract `risk_reserve_pct` from the climate risk assessment above "
        "(default to 0.0 if missing or unparseable).\n"
        "3. Call `get_dispatch_plan` using the telemetry values and that "
        "risk_reserve_pct.\n\n"
        "Respond ONLY with compact JSON containing the full dispatch plan "
        "(grid_import_kw, battery_discharge_kw, battery_charge_kw, "
        "solar_curtailed_kw, estimated_cost, reserved_battery_kwh, notes) "
        "plus a 'summary' field with one sentence explaining the plan in "
        "plain language for a grid operator. Do not include text outside JSON."
    ),
    tools=[get_grid_telemetry, get_dispatch_plan],
    output_key="dispatch_plan_result",
)
