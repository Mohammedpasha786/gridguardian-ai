"""
Agent-wiring tests. These deliberately do NOT call any LLM (no API key
required in CI) -- they verify the multi-agent pipeline is assembled
correctly: the right sub-agents, in the right order, each with the
right tools and output_key wired into the next agent's instruction.
"""

from gridguardian.agents.climate_risk_agent import climate_risk_agent
from gridguardian.agents.demand_forecast_agent import demand_forecast_agent
from gridguardian.agents.dispatch_optimizer_agent import dispatch_optimizer_agent
from gridguardian.agents.orchestrator import root_agent
from gridguardian.agents.resilience_advisor_agent import resilience_advisor_agent


def test_orchestrator_has_four_sub_agents_in_order():
    names = [a.name for a in root_agent.sub_agents]
    assert names == [
        "climate_risk_agent",
        "demand_forecast_agent",
        "dispatch_optimizer_agent",
        "resilience_advisor_agent",
    ]


def test_climate_risk_agent_has_expected_tool_and_output_key():
    tool_names = {t.__name__ for t in climate_risk_agent.tools}
    assert "get_climate_risk_assessment" in tool_names
    assert climate_risk_agent.output_key == "climate_risk_result"


def test_demand_forecast_agent_has_expected_tools():
    tool_names = {t.__name__ for t in demand_forecast_agent.tools}
    assert {"get_weather_forecast", "get_demand_forecast"} <= tool_names
    assert demand_forecast_agent.output_key == "demand_forecast_result"


def test_dispatch_optimizer_agent_references_upstream_state():
    assert "{climate_risk_result}" in dispatch_optimizer_agent.instruction
    assert "{demand_forecast_result}" in dispatch_optimizer_agent.instruction
    tool_names = {t.__name__ for t in dispatch_optimizer_agent.tools}
    assert {"get_grid_telemetry", "get_dispatch_plan"} <= tool_names


def test_resilience_advisor_agent_has_no_tools_and_reads_all_upstream_state():
    assert resilience_advisor_agent.tools == []
    for key in ("{climate_risk_result}", "{demand_forecast_result}", "{dispatch_plan_result}"):
        assert key in resilience_advisor_agent.instruction
