import pytest

from gridguardian.security.controls import (
    RateLimiter,
    ValidationError,
    validate_identifier,
    validate_latitude,
    validate_longitude,
    validate_percent,
    validate_range,
)


def test_validate_range_within_bounds():
    assert validate_range(5.0, name="x", min_value=0, max_value=10) == 5.0


def test_validate_range_rejects_out_of_bounds():
    with pytest.raises(ValidationError):
        validate_range(15.0, name="x", min_value=0, max_value=10)


def test_validate_range_rejects_non_numeric():
    with pytest.raises(ValidationError):
        validate_range("oops", name="x", min_value=0, max_value=10)  # type: ignore[arg-type]


@pytest.mark.parametrize("lat", [-90.0, 0.0, 90.0])
def test_validate_latitude_accepts_boundary(lat):
    assert validate_latitude(lat) == lat


@pytest.mark.parametrize("lat", [-91.0, 91.0, 180.0])
def test_validate_latitude_rejects_out_of_range(lat):
    with pytest.raises(ValidationError):
        validate_latitude(lat)


def test_validate_longitude_rejects_out_of_range():
    with pytest.raises(ValidationError):
        validate_longitude(200.0)


def test_validate_percent_rejects_negative():
    with pytest.raises(ValidationError):
        validate_percent(-1.0, name="soc")


def test_validate_identifier_rejects_injection_chars():
    with pytest.raises(ValidationError):
        validate_identifier("SUB-01; DROP TABLE grid", name="substation_id")


def test_validate_identifier_accepts_normal_id():
    assert validate_identifier("SUB-01", name="substation_id") == "SUB-01"


def test_validate_identifier_rejects_too_long():
    with pytest.raises(ValidationError):
        validate_identifier("x" * 100, name="substation_id", max_length=64)


def test_rate_limiter_blocks_after_capacity():
    limiter = RateLimiter(max_calls_per_minute=3)
    results = [limiter.allow("caller-a", "tool-x") for _ in range(4)]
    assert results == [True, True, True, False]


def test_rate_limiter_tracks_callers_independently():
    limiter = RateLimiter(max_calls_per_minute=1)
    assert limiter.allow("caller-a", "tool-x") is True
    assert limiter.allow("caller-b", "tool-x") is True
    assert limiter.allow("caller-a", "tool-x") is False
