import pytest

from gridguardian.security.controls import ValidationError
from gridguardian.tools.grid_tools import (
    get_climate_risk_assessment,
    get_demand_forecast,
    get_dispatch_plan,
    get_grid_telemetry,
    get_weather_forecast,
)


def test_get_weather_forecast_returns_requested_hours():
    result = get_weather_forecast(13.08, 80.27, hours=12)
    assert len(result["points"]) == 12
    for p in result["points"]:
        assert "temperature_c" in p
        assert "timestamp" in p


def test_get_weather_forecast_rejects_bad_latitude():
    with pytest.raises(ValidationError):
        get_weather_forecast(999.0, 80.27, hours=12)


def test_get_climate_risk_assessment_shape():
    result = get_climate_risk_assessment("Coastal-North", 13.08, 80.27)
    for key in (
        "heatwave_probability",
        "flood_risk_index",
        "storm_surge_risk_index",
        "sea_level_rise_mm_per_yr",
        "extreme_event_trend_pct",
    ):
        assert key in result
    assert 0.0 <= result["flood_risk_index"] <= 1.0
    assert 0.0 <= result["heatwave_probability"] <= 1.0


def test_get_climate_risk_assessment_is_deterministic_for_same_region():
    a = get_climate_risk_assessment("Coastal-North", 13.08, 80.27)
    b = get_climate_risk_assessment("Coastal-North", 13.08, 80.27)
    assert a["flood_risk_index"] == b["flood_risk_index"]


def test_get_grid_telemetry_shape():
    result = get_grid_telemetry("SUB-01")
    assert result["substation_id"] == "SUB-01"
    assert result["battery_capacity_kwh"] > 0
    assert 0 <= result["battery_soc_pct"] <= 100


def test_get_demand_forecast_returns_requested_hours():
    result = get_demand_forecast(13.08, 80.27, hours=8)
    assert len(result["forecast"]) == 8
    for point in result["forecast"]:
        assert point["predicted_load_kw"] > 0
        assert point["lower_bound_kw"] <= point["predicted_load_kw"] <= point["upper_bound_kw"]


def test_get_dispatch_plan_balances_power():
    plan = get_dispatch_plan(
        load_kw=200.0,
        solar_available_kw=80.0,
        battery_soc_pct=60.0,
        battery_capacity_kwh=500.0,
        grid_price_per_kwh=0.15,
        risk_reserve_pct=0.0,
    )
    supply = plan["grid_import_kw"] + plan["battery_discharge_kw"] + (80.0 - plan["solar_curtailed_kw"])
    demand = 200.0 + plan["battery_charge_kw"]
    assert abs(supply - demand) < 1e-3


def test_get_dispatch_plan_with_reserve_reduces_available_discharge():
    no_reserve = get_dispatch_plan(200.0, 0.0, 80.0, 500.0, 0.15, risk_reserve_pct=0.0)
    with_reserve = get_dispatch_plan(200.0, 0.0, 80.0, 500.0, 0.15, risk_reserve_pct=0.3)
    assert with_reserve["reserved_battery_kwh"] > no_reserve["reserved_battery_kwh"]


def test_get_dispatch_plan_rejects_invalid_soc():
    with pytest.raises(ValidationError):
        get_dispatch_plan(200.0, 80.0, 150.0, 500.0, 0.15)
