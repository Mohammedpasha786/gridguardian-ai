from gridguardian.dispatch_optimizer import optimize_dispatch


def test_optimize_dispatch_prefers_solar_over_grid():
    plan = optimize_dispatch(
        load_kw=100.0,
        solar_available_kw=100.0,
        battery_soc_pct=50.0,
        battery_capacity_kwh=500.0,
        grid_price_per_kwh=0.20,
    )
    # All load should be met by free solar; grid import should be ~0.
    assert plan.grid_import_kw < 1.0
    assert plan.solar_curtailed_kw < 1.0


def test_optimize_dispatch_uses_battery_when_solar_insufficient():
    plan = optimize_dispatch(
        load_kw=200.0,
        solar_available_kw=50.0,
        battery_soc_pct=80.0,
        battery_capacity_kwh=500.0,
        grid_price_per_kwh=0.20,
    )
    assert plan.battery_discharge_kw > 0


def test_optimize_dispatch_infeasible_degrades_gracefully():
    plan = optimize_dispatch(
        load_kw=100000.0,
        solar_available_kw=0.0,
        battery_soc_pct=0.0,
        battery_capacity_kwh=500.0,
        grid_price_per_kwh=0.20,
        max_grid_import_kw=400.0,
        max_battery_power_kw=100.0,
    )
    assert "infeasible" in plan.notes.lower() or "degraded" in plan.notes.lower() or plan.grid_import_kw == 400.0


def test_optimize_dispatch_reserve_floor_blocks_discharge_when_at_floor():
    plan = optimize_dispatch(
        load_kw=200.0,
        solar_available_kw=0.0,
        battery_soc_pct=20.0,
        battery_capacity_kwh=500.0,
        grid_price_per_kwh=0.20,
        risk_reserve_pct=0.3,  # reserve (150 kWh) exceeds current energy (100 kWh)
    )
    assert plan.battery_discharge_kw == 0.0
