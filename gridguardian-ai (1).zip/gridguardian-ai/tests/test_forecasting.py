from gridguardian.data.sources import fetch_weather_forecast
from gridguardian.forecasting import forecast_demand


def test_forecast_demand_returns_one_point_per_weather_point():
    weather = fetch_weather_forecast(13.08, 80.27, hours=10)
    forecast = forecast_demand(weather)
    assert len(forecast) == len(weather)


def test_forecast_demand_bounds_are_ordered():
    weather = fetch_weather_forecast(13.08, 80.27, hours=10)
    forecast = forecast_demand(weather)
    for point in forecast:
        assert point.lower_bound_kw <= point.predicted_load_kw <= point.upper_bound_kw


def test_forecast_demand_predicts_positive_load():
    weather = fetch_weather_forecast(13.08, 80.27, hours=24)
    forecast = forecast_demand(weather)
    assert all(p.predicted_load_kw > 0 for p in forecast)
