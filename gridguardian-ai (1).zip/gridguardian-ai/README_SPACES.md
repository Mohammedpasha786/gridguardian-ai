---
title: GridGuardian AI
emoji: 🔋
colorFrom: cyan
colorTo: blue
sdk: gradio
sdk_version: "5.0"
app_file: app.py
pinned: true
license: mit
short_description: Climate-Resilient Smart Grid Multi-Agent System
---

# GridGuardian AI

See the full README in the repository root for setup and architecture docs.
