# GridGuardian AI

**Climate-Resilient Smart Grid Multi-Agent System**
*Kaggle 5-Day AI Agents Intensive — Vibe Coding Capstone — Agents for Good track*

![Architecture](docs/images/architecture.png)

## The problem

Utility operators running solar + battery microgrids make dispatch decisions
(how much to import from the grid vs. discharge the battery vs. curtail
solar) largely on **today's** conditions. They rarely have a cheap, fast way
to fold in **tomorrow's climate risk** — an approaching heatwave that will
spike demand, or elevated flood/storm-surge risk that means the battery
should be kept charged for an islanding event, not drained for marginal
savings. SDG 7 (Affordable & Clean Energy) and SDG 13 (Climate Action) both
depend on grids that are not just efficient, but resilient.

## The solution

GridGuardian AI is a four-agent pipeline, built on Google's Agent
Development Kit (ADK), that turns "what should this microgrid do right now"
into a climate-aware decision in one call:

1. **Climate Risk Agent** — pulls heatwave/flood/storm-surge/sea-level-rise
   indicators for the region (synthetic model anchored to IPCC AR6 ranges)
   and derives a battery reserve fraction.
2. **Demand Forecast Agent** — forecasts the next N hours of load using a
   bagged-regression-tree model conditioned on a real weather forecast.
3. **Dispatch Optimizer Agent** — solves a least-cost linear program
   (`scipy.optimize.linprog`) over grid import / battery / solar curtailment,
   holding back the climate-risk-derived reserve.
4. **Resilience Advisor Agent** — synthesizes all of the above into a
   plain-language Markdown briefing an operator can act on in under a minute.

Why agents, specifically? Each stage is a genuinely different reasoning
task (hazard interpretation, statistical forecasting, constrained
optimization, plain-language synthesis) that benefits from its own focused
instruction prompt and tool set, while still needing to flow into a single
coherent recommendation — exactly the problem multi-agent orchestration is
for.

## Key concepts demonstrated

| Concept | Where |
|---|---|
| Agent / Multi-agent system (ADK) | `src/gridguardian/agents/` — 4 `LlmAgent`s composed via `SequentialAgent` |
| MCP Server | `src/gridguardian/mcp_server/server.py` — exposes the same tools to any MCP client |
| Security features | `src/gridguardian/security/controls.py` — rate limiting, input validation, secrets via env, audit logging |
| Deployability | `Dockerfile`, `docker-compose.yml`, `.github/workflows/` |
| Agent skills (CLI) | `gridguardian` CLI (`src/gridguardian/cli.py`) — `pip install -e .` and run `gridguardian --help` |
| Antigravity | Demonstrated in the submission video |

## Quickstart

```bash
git clone <this-repo>
cd gridguardian-ai
python -m venv .venv && source .venv/bin/activate
pip install -e .
cp .env.example .env   # add your GOOGLE_API_KEY

# Tool-level commands work immediately, no LLM call:
gridguardian telemetry --substation SUB-01
gridguardian climate-risk --region Coastal-North --lat 13.08 --lon 80.27
gridguardian forecast --lat 13.08 --lon 80.27 --hours 24
gridguardian dispatch --load 220 --solar 90 --soc 60 --capacity 500 --price 0.15

# Full multi-agent pipeline (requires GOOGLE_API_KEY):
gridguardian briefing --region Coastal-North --lat 13.08 --lon 80.27

# Inspect/step through the agents in ADK's Dev UI:
adk web src/gridguardian/agents

# Run the MCP server standalone:
gridguardian serve-mcp --http --port 8765
```

## Repository layout

```
src/gridguardian/
  agents/            4 ADK agents + orchestrator (SequentialAgent)
  tools/             shared tool functions (used by agents AND the MCP server)
  mcp_server/        FastMCP server exposing the tools
  security/          rate limiting, validation, secrets, audit logging
  data/              tiered-fallback data sources (live API -> synthetic)
  forecasting.py     bagged-regression-tree demand model
  dispatch_optimizer.py   linprog-based least-cost dispatch
  cli.py             `gridguardian` CLI ("agent skill")
  main.py            programmatic Runner entry point
tests/               37 pytest tests across security, tools, optimization,
                     forecasting, and agent wiring
docs/                ARCHITECTURE.md, SECURITY.md, DEPLOYMENT.md, diagrams
.github/workflows/   CI (lint + security scan + tests) and Docker publish
```

## Testing

```bash
pip install pytest pytest-asyncio
PYTHONPATH=src pytest tests/ -v
```

All 37 tests pass without requiring a `GOOGLE_API_KEY` — they test the
deterministic tool layer and the agent wiring directly, not LLM output.

## Further reading

- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — full system design
- [`docs/SECURITY.md`](docs/SECURITY.md) — security controls in detail
- [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md) — local, Docker, and CI/CD setup
- [`WRITEUP.md`](WRITEUP.md) — the Kaggle Writeup submission text

## License

MIT — see [LICENSE](LICENSE).
